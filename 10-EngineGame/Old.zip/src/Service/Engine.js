class Engine {
    #canvas = null;
    #ctx = null;
    #image = null
    init(width = 256, height = 240, color = "#fafafa") {
        this.#canvas = document.createElement("CANVAS");
        this.#canvas.width = width;
        this.#canvas.height = height;
        this.#canvas.style.backgroundColor = color;
        document.body.appendChild(this.#canvas);
        this.#ctx = this.canvas.getContext("2d");
    }
    syncVBlank() {
        //wait(1000)
    }

    loadSpriteMap(image, numberHorizontal, numberVertical) {
        this.#image = image;
        let count = 0;
        for (let row = 0; row < numberVertical; row++) {
            for (let col = 0; col < numberHorizontal; col++) {
                this.spriteMap[count] = new Entity(count, col * 8, row * 8, 8, 8);
                count++;
            }
        }
    }

    draw(spriteId, x, y, width = 8, height = 8) {
        let entity = this.spriteMap[spriteId];
        drawImage(image, entity.x, entity.y, entity.width, entity.height, x, y, width, height)
    }

    clear() {
        let { width, height } = this.canvas
        this.canvas.clearRect(0, 0, width, height);
    }

}
/*
drawImage(image, dx, dy)
drawImage(image, dx, dy, dWidth, dHeight)
drawImage(image, sx, sy, sWidth, sHeight, dx, dy, dWidth, dHeight)
*/